import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Experience from "./components/Experience";
import Projects from "./components/Projects";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
export default function Page() {
  return (
    <>
      <Navbar />
      <main>
        <section className="text-center py-20">
          <h1 className="text-4xl font-bold text-white">
            NIKHIL'S PORTFOLIO
          </h1>
          <p className="mt-4 text-white/70">
           
          </p>
        </section>

        <Hero />
        <About />
        <Experience />
        <Projects />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
