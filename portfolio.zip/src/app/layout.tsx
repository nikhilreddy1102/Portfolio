import "./globals.css";
import type { Metadata } from "next";
import GlobalBackground from "./components/GlobalBackground";

export const metadata: Metadata = {
  title: "Portfolio",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="relative bg-transparent">
        <GlobalBackground />   {/* one global mount */}
        <div className="relative z-10">{children}</div>
      </body>
    </html>
  );
}
