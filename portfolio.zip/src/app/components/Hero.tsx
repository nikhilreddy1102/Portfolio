import { Mail, Linkedin, Github, Download } from "lucide-react";
import BackgroundSpotlight from "./BackgroundSpotlight";
export default function Hero() {
  return (
    <section id="home" className="min-h-[88vh] flex items-center">
         <BackgroundSpotlight />
      <div className="mx-auto max-w-6xl px-4 py-16 lg:py-24 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        
        {/* Left: text teaser */}
        <div className="space-y-6">
          <h1 className="text-3xl text-gray-300 sm:text-4xl lg:text-5xl font-bold leading-tight">
            <a href="#about" className="cursor-pointer hover:opacity-80">
              Nikhil Reddy
            </a>
            <span className="block mt-2 text-gray-300 text-xl lg:text-2xl font-medium">
              Software Developer • Java Full Stack Developer • Frontend Developer
            </span>
          </h1>

          <p className="text-gray-300 max-w-xl">
            I’m a Software Developer with 4+ years of experience building 
            full-stack and cloud-native applications using Java, Spring Boot, 
            React/Next.js, and AWS. With proven experience in Data Structures and Algorithms, 
            I specialize in designing scalable microservices and secure APIs that perform under
            high demand. I’m now seeking opportunities as a Software Developer,
            Java Full Stack Engineer, or React/Frontend Developer to continue creating impactful systems.
          </p>

      
          {/* Social Links with Icons */}
          <div className="flex flex-wrap gap-3">
            <a
              href="mailto:nikhilkothapally.reddy@gmail.com"
              className="rounded-md bg-white px-4 py-2 text-black hover:opacity-90 flex items-center justify-center"
            >
              <Mail size={20} />
            </a>
            <a
              href="https://www.linkedin.com/in/sj6038372a/"
              target="_blank"
              className="rounded-md border border-white/30 px-4 py-2 hover:bg-white/10 flex items-center justify-center"
            >
              <Linkedin size={20} />
            </a>
            <a
              href="https://github.com/"
              target="_blank"
              className="rounded-md border border-white/30 px-4 py-2 hover:bg-white/10 flex items-center justify-center"
            >
              <Github size={20} />
            </a>
            <a
              href="/NikhilReddy_Resume.pdf"
              className="rounded-md bg-white/10 px-4 py-2 hover:bg-white/20 flex items-center justify-center"
            >
              <Download size={20} />
            </a>
          </div>
        </div>

        {/* Right: placeholder visual box (we’ll replace with background effect later) */}
        <div className="h-[340px] sm:h-[420px] lg:h-[520px] rounded-2xl border border-white/10 bg-white/[0.02]"></div>
      </div>
    </section>
  );
}
