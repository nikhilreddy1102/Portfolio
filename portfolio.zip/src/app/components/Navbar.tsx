import { Download } from "lucide-react";   // 👈 import the icon

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 bg-black/40 backdrop-blur border-b border-white/10">
      <nav className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
        <div className="font-semibold tracking-wide text-gray-300">Nikhil Reddy</div>
        <div className="flex items-center gap-6 text-sm">
          <a href="#about" className="hover:opacity-80 text-gray-300">About</a>
          <a href="#experience" className="hover:opacity-80 text-gray-300">Experience</a>
          <a href="#projects" className="hover:opacity-80 text-gray-300">Projects</a>
          <a href="#contact" className="hover:opacity-80 text-gray-300">Contact</a>

          {/* Resume with icon */}
          <a
            href="/NikhilReddy_Resume.pdf"
            className="flex items-center gap-2 rounded-md bg-white/10 text-gray-300 px-3 py-1.5 hover:bg-white/20"
          >
            <Download size={16} /> Resume
          </a>
        </div>
      </nav>
    </header>
  );
}
