export default function About() {
  return (
    <section id="about" className="min-h-screen flex items-center bg-white text-black">
      <div className="mx-auto max-w-5xl px-4 py-20 lg:py-28 space-y-8">
        <h2 className="text-3xl lg:text-4xl font-bold text-center">About Me</h2>

        <p className="text-lg leading-relaxed text-gray-800">
          Over the past four years, I’ve designed and developed enterprise-grade
          <strong> microservices</strong>, <strong>APIs</strong>, and 
          <strong> responsive interfaces</strong> across industries such as
          <strong> banking, healthcare, and media</strong>. My expertise spans
          <strong> Java (8–17), Spring Boot,</strong> and <strong>distributed systems</strong> 
          on the backend, and <strong>React/Next.js</strong> with 
          <strong> Tailwind CSS</strong> on the frontend, all deployed through
          <strong> CI/CD pipelines</strong> on AWS and Azure.
        </p>

        <p className="text-lg leading-relaxed text-gray-800">
          I’ve implemented secure architectures with <strong>OAuth2</strong>, 
          <strong> JWT</strong>, and <strong>Kafka</strong> for real-time messaging,
          while containerizing applications with <strong>Docker</strong> and 
          <strong>Kubernetes</strong> to ensure high availability.
        </p>

        <p className="text-lg leading-relaxed text-gray-800">
          With proven experience in <strong>Data Structures and Algorithms</strong>,
          I apply graph-based models, optimization techniques, and efficient query
          strategies to improve performance and stability.
        </p>

        <p className="text-lg leading-relaxed text-gray-800">
          Experienced in <strong>agile delivery</strong> and 
          <strong> cross-functional collaboration</strong>, I’m passionate about
          roles that challenge me to architect scalable microservices, optimize
          performance, and create engaging user experiences in full-stack or
          frontend engineering.
        </p>
      </div>
    </section>
  );
}
